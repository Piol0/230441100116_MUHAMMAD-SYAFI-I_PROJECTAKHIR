/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package garden;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

/**
 *
 * @author safik
 */
public class utama extends javax.swing.JFrame {
    Connection conn;
    private DefaultTableModel modelPlants, modelTasks, modelGrowth;
    /**
     * Creates new form
     */
    public utama() {
        initComponents();
        this.setLocationRelativeTo(null);
        conn = koneksi.getConnection();
        
        displayTask();
        table();
        loadDataPlants();
        loadComboBoxTanaman();
        loadComboBoxTanaman2();
        loadTextfieldTugas();
        loadDataGardenTask();
        loadDataGrowth();
        
        cbJenis.setSelectedIndex(-1);
        cbTanaman.setSelectedIndex(-1);
        cbStatus.setSelectedIndex(-1);
        cbTanaman2.setSelectedIndex(-1);
        
        disableButton();
        
        addNumberKeyListener(idPlant);
        addNumberKeyListener(idTask);
        addNumberKeyListener(idGrowth);
        
        docListener();
        
    }
    
    private void addNumberKeyListener(JTextField textField) {
    textField.addKeyListener(new KeyAdapter() {
        @Override
        public void keyTyped(KeyEvent e) {
            if (!Character.isDigit(e.getKeyChar())) {
                e.consume();
                JOptionPane.showMessageDialog(null, "Hanya boleh diisi dengan angka!", 
                        "Input Error", JOptionPane.ERROR_MESSAGE);

            }
        }
        
         
    });
      
    }
    
    private void docListener(){
        addDocumentListener(idPlant);
        addDocumentListener(namaT);
        addDocumentListener(rencana);
        
        addDocumentListener(idTask);
        addDocumentListener(tugas);
        
        addDocumentListener(idGrowth);
        addDocumentListener(deskripsi);
        addDocumentListener(rencana);
        

        cbJenis.addItemListener(e -> toggleButtonsPlants());
        cbTanaman.addItemListener(e -> toggleButtonsTask());
        cbStatus.addItemListener(e -> toggleButtonsTask());
        cbTanaman2.addItemListener(e -> toggleButtonsGrowth());
    }
    
    private void disableButton(){
        btnDeleteP.setEnabled(false);
        btnUpdateP.setEnabled(false);
        btnCreateP.setEnabled(false);
                
        btnDeleteT.setEnabled(false);
        btnUpdateT.setEnabled(false);
        btnCreateT.setEnabled(false);
                
        btnDeleteG.setEnabled(false);
        btnUpdateG.setEnabled(false);
        btnCreateG.setEnabled(false);
    }
    
     private void addDocumentListener(JTextField textField) {
        textField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                toggleButtonsPlants();
                toggleButtonsTask();
                toggleButtonsGrowth();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                toggleButtonsPlants();
                toggleButtonsTask();
                toggleButtonsGrowth();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                
            }
        });
    }
    
//  ========================Toggle Buttons=====================   
    private void toggleButtonsPlants() {
        boolean isIdFilled = !idPlant.getText().trim().isEmpty();       
        boolean isNamaFilled = !namaT.getText().trim().isEmpty();      
        boolean isJenisSelected = cbJenis.getSelectedItem() != null;    
        boolean isRencanaFilled = !rencana.getText().trim().isEmpty();  

        btnDeleteP.setEnabled(isIdFilled && !isNamaFilled && !isJenisSelected && !isRencanaFilled);
        btnCreateP.setEnabled(!isIdFilled && isNamaFilled && isJenisSelected && isRencanaFilled);
        btnUpdateP.setEnabled(isIdFilled && isNamaFilled && isJenisSelected && isRencanaFilled);
    }
    
    private void toggleButtonsTask() {
        boolean isIdFilled = !idTask.getText().trim().isEmpty();             
        boolean isTanamanSelected = cbTanaman.getSelectedItem() != null;    
        boolean isTugasFilled = !tugas.getText().trim().isEmpty();
        boolean isStatusSelected = cbStatus.getSelectedItem() != null;

        btnDeleteT.setEnabled(isIdFilled && !isStatusSelected && !isTanamanSelected && !isTugasFilled);
        btnCreateT.setEnabled(!isIdFilled && isTanamanSelected && isTugasFilled && isStatusSelected);
        btnUpdateT.setEnabled(isIdFilled && isStatusSelected && isTanamanSelected && isTugasFilled);
    }
    
    private void toggleButtonsGrowth() {
        boolean isIdFilled = !idGrowth.getText().trim().isEmpty();             
        boolean isTanamanSelected = cbTanaman2.getSelectedItem() != null;    
        boolean isDeskripsiFilled = !deskripsi.getText().trim().isEmpty();

        btnDeleteG.setEnabled(isIdFilled  && !isTanamanSelected && !isDeskripsiFilled);
        btnCreateG.setEnabled(!isIdFilled && isTanamanSelected && isDeskripsiFilled);
        btnUpdateG.setEnabled(isIdFilled && isTanamanSelected && isDeskripsiFilled);
    }
//    ====================Toggle Buttons========================
    
    private void table(){
         modelPlants = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };
//        modelPlants = new DefaultTableModel();
        tblPlants.setModel(modelPlants);
        
        modelPlants.addColumn("No");
        modelPlants.addColumn("Plant ID");
        modelPlants.addColumn("Nama Tanaman");
        modelPlants.addColumn("Jenis");
        modelPlants.addColumn("Rencana Tugas");
        JTableHeader h = tblPlants.getTableHeader();
        h.setFont(new Font("Segoe UI", Font.BOLD, 12)); 
        h.setForeground(Color.BLACK);
        DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) h.getDefaultRenderer();
        headerRenderer.setHorizontalAlignment(SwingConstants.CENTER); 
        tblPlants.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tblPlants.getColumnModel().getColumn(0).setPreferredWidth(30); 
        tblPlants.getColumnModel().getColumn(1).setPreferredWidth(60); 
        tblPlants.getColumnModel().getColumn(2).setPreferredWidth(120); 
        tblPlants.getColumnModel().getColumn(3).setPreferredWidth(100); 
        tblPlants.getColumnModel().getColumn(4).setPreferredWidth(209); 
        
        
        
        modelTasks = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };
//        modelTasks = new DefaultTableModel();
        tblTasks.setModel(modelTasks);
        
        modelTasks.addColumn("No");
        modelTasks.addColumn("Tasks ID");
        modelTasks.addColumn("Nama Tanaman");
        modelTasks.addColumn("Tugas");
        modelTasks.addColumn("Status");
        
         tblTasks.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                String status = value.toString();

                
                if ("Pending".equalsIgnoreCase(status)) {
                    c.setBackground(Color.RED);
                    c.setForeground(Color.WHITE);
                } else if ("In Progress".equalsIgnoreCase(status)) {
                    c.setBackground(Color.YELLOW);
                    c.setForeground(Color.BLACK);
                } else if ("Completed".equalsIgnoreCase(status)) {
                    c.setBackground(Color.GREEN);
                    c.setForeground(Color.WHITE);
                } else {
                    
                    c.setBackground(Color.WHITE);
                    c.setForeground(Color.BLACK);
                }

               
                if (isSelected) {
                    c.setBackground(Color.BLUE);
                    c.setForeground(Color.WHITE);
                }

                return c;
            }
        });
        
        JTableHeader T = tblTasks.getTableHeader();
        T.setFont(new Font("Segoe UI", Font.BOLD, 12)); 
        T.setForeground(Color.BLACK);
        DefaultTableCellRenderer hr = (DefaultTableCellRenderer) T.getDefaultRenderer();
        hr.setHorizontalAlignment(SwingConstants.CENTER); 
        tblTasks.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tblTasks.getColumnModel().getColumn(0).setPreferredWidth(30); 
        tblTasks.getColumnModel().getColumn(1).setPreferredWidth(70); 
        tblTasks.getColumnModel().getColumn(2).setPreferredWidth(120); 
        tblTasks.getColumnModel().getColumn(3).setPreferredWidth(210); 
        tblTasks.getColumnModel().getColumn(4).setPreferredWidth(104);
        
        
        modelGrowth = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
//        modelGrowth = new DefaultTableModel();
        tblGrowth.setModel(modelGrowth);
        
        modelGrowth.addColumn("No");
        modelGrowth.addColumn("Growth ID");
        modelGrowth.addColumn("Nama Tanaman");
        modelGrowth.addColumn("Deskripsi");
        JTableHeader G = tblGrowth.getTableHeader();
        G.setFont(new Font("Segoe UI", Font.BOLD, 12)); 
        G.setForeground(Color.BLACK);
        DefaultTableCellRenderer HR = (DefaultTableCellRenderer) G.getDefaultRenderer();
        HR.setHorizontalAlignment(SwingConstants.CENTER);
        tblGrowth.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tblGrowth.getColumnModel().getColumn(0).setPreferredWidth(30); 
        tblGrowth.getColumnModel().getColumn(1).setPreferredWidth(70); 
        tblGrowth.getColumnModel().getColumn(2).setPreferredWidth(120); 
        tblGrowth.getColumnModel().getColumn(3).setPreferredWidth(314); 
        
    }
    
    private void displayTask() {
        String query = "SELECT status, COUNT(*) AS total FROM garden_tasks GROUP BY status";
        
        try (PreparedStatement ps = conn.prepareStatement(query); 
        ResultSet rs = ps.executeQuery()) {
        
        int pendingCount = 0;
        int inProgressCount = 0;
        int completedCount = 0;

            
            while (rs.next()) {
                String status = rs.getString("status");
                int total = rs.getInt("total");

                switch (status) {
                    case "Pending":
                        pendingCount = total;
                        break;
                    case "In Progress":
                        inProgressCount = total;
                        break;
                    case "Completed":
                        completedCount = total;
                        break;
                }
            }

           lblPending.setText(String.valueOf(": "+pendingCount));
           lblProgress.setText(String.valueOf(": "+inProgressCount));
           lblCompleted.setText(String.valueOf(": "+completedCount));
                

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    

//============================Plants============================
    private void loadDataPlants(){
        modelPlants.setRowCount(0);

      try {
          String sql = "SELECT * FROM plants";
          PreparedStatement ps = conn.prepareStatement(sql);
          ResultSet rs = ps.executeQuery();
          int no = 1;
          while (rs.next()) {
             // Menambahkan baris ke dalam model tabel
             modelPlants.addRow(new Object[]{
             no++,
             rs.getInt("plant_id"),
             rs.getString("nama"),
             rs.getString("jenis"),
             rs.getString("rencana_tugas")
           });
          }
      } catch (SQLException e) {
         System.out.println("Error Save Data" + e.getMessage());
       }
    }
     
    private void tambahDataPlants(){
        String Nama = namaT.getText();
        String Jenis = (String) cbJenis.getSelectedItem();
        String Rencana = rencana.getText();
        
        try {
           
            String sql = "INSERT INTO plants (nama, jenis, rencana_tugas) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            
            ps.setString(1,Nama);
            ps.setString(2,Jenis);
            ps.setString(3, Rencana);
            
            if(ps.executeUpdate() > 0){
               JOptionPane.showMessageDialog(this, "Data tanaman berhasil ditambahkan!");
               loadDataPlants();
               loadComboBoxTanaman();
               loadComboBoxTanaman2();
               resetP();
               resetT();
               resetG();
            }
            
        } catch (SQLException e) {
            System.out.println("Error saat menambahkan data tanaman: " + e.getMessage());
        }
    }
    
    private void updateDataPlants(){
        int ID = Integer.parseInt(idPlant.getText());
        String Nama = namaT.getText();
        String Jenis = (String) cbJenis.getSelectedItem();
        String Rencana = rencana.getText();
        
        try {
          String sql = "UPDATE plants SET nama = ?, jenis = ?, rencana_tugas = ? WHERE plant_id = ?";
          PreparedStatement ps = conn.prepareStatement(sql);
          ps.setString(1, Nama);
          ps.setString(2, Jenis);
          ps.setString(3, Rencana);
          ps.setInt(4, ID);
          
          if (ps.executeUpdate() > 0) {
            JOptionPane.showMessageDialog(this, "Data updated successfully");
            loadDataPlants();
             loadComboBoxTanaman();
             loadComboBoxTanaman2();
              resetP();
              resetT();
              resetG();
        } else {
            JOptionPane.showMessageDialog(this, "Data tidak ditemukan untuk ID tersebut!", "Update Error", JOptionPane.WARNING_MESSAGE);
        }
      }  catch (SQLException e) {
          System.out.println("Error Save Data" + e.getMessage());
      }
    }
    
    private void deleteDataPlants() {
    int ID = Integer.parseInt(idPlant.getText());
    
    int response = JOptionPane.showConfirmDialog(this, 
        "Apakah Anda yakin ingin menghapus data ini?", 
        "Konfirmasi Hapus", 
        JOptionPane.YES_NO_OPTION, 
        JOptionPane.QUESTION_MESSAGE);
    
    if (response == JOptionPane.YES_OPTION) {
        try {
            String sql = "DELETE FROM plants WHERE plant_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, ID);

            int rowsAffected = ps.executeUpdate();  // Mengeksekusi query dan mengecek baris yang terpengaruh
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Data deleted successfully");
                loadDataPlants();
                loadComboBoxTanaman();
                loadComboBoxTanaman2();
                resetP();
                resetT();
                resetG();
            } else {
                JOptionPane.showMessageDialog(this, "Data tidak ditemukan untuk ID tersebut!", "Delete Error", JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException e) {
            System.out.println("Error delete Data: " + e.getMessage());
        }
    } else {
        JOptionPane.showMessageDialog(this, "Penghapusan data dibatalkan.");
    }
}

//============================Plants============================
    
//============================Combo Box=========================
   private void loadComboBoxTanaman(){
        cbTanaman.removeAllItems();
        try {
            String sql = "SELECT plant_id, nama FROM plants";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
        
            while (rs.next()) {
                String idNama = rs.getInt("plant_id") + " - " + rs.getString("nama");
                cbTanaman.addItem(idNama);
            }
        } catch (SQLException e) {
            System.out.println("Error loading tanaman ComboBox: " + e.getMessage());
        }
        
        cbTanaman.setMaximumRowCount(10);
    }
    
   private void loadTextfieldTugas() {
    cbTanaman.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String selectedItem = (String) cbTanaman.getSelectedItem();
            if (selectedItem != null && !selectedItem.isEmpty()) {
                try {
                    int plantId = Integer.parseInt(selectedItem.split(" - ")[0]);

                    String sql = "SELECT rencana_tugas FROM plants WHERE plant_id = ?";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setInt(1, plantId);
                    ResultSet rs = ps.executeQuery();

                    tugas.setText("");
                    
                    if (rs.next()) {
                        String taskPlan = rs.getString("rencana_tugas");
                        tugas.setText(taskPlan);
                    }
                } catch (SQLException ex) {
                    System.out.println("Error loading tasks: " + ex.getMessage());
                }
            }
        }
    });
    }
   
   
   private void loadComboBoxTanaman2(){
        cbTanaman2.removeAllItems();
        try {
            String sql = "SELECT plant_id, nama FROM plants";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
        
            while (rs.next()) {
                String idNama = rs.getInt("plant_id") + " - " + rs.getString("nama");
                cbTanaman2.addItem(idNama);
            }
        } catch (SQLException e) {
            System.out.println("Error loading tanaman ComboBox: " + e.getMessage());
        }
        
        cbTanaman2.setMaximumRowCount(10);
    }
//============================Combo Box=========================
    
//============================Garden Task========================
    private void loadDataGardenTask(){
        modelTasks.setRowCount(0);
        try {
            String sql = "SELECT t.task_id, t.status, p.rencana_tugas, p.nama "
                     + "FROM garden_tasks t "
                     + "JOIN plants p ON t.plant_id = p.plant_id ";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            int no = 1;
            while (rs.next()) {
                modelTasks.addRow(new Object[]{
                    no++,
                    rs.getString("task_id"),
                    rs.getString("nama"),
                    rs.getString("rencana_tugas"),
                    rs.getString("status"),
                   
            });
        }
        } catch (SQLException e) {
            System.out.println("Error loading garden task data: " + e.getMessage());
        }      
    }
    
    private void tambahDataGardenTasks(){
        String Tugas = tugas.getText();
        try {
            String sql = "INSERT INTO garden_tasks (plant_id, nama_tugas, status) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            
            ps.setInt(1, Integer.parseInt(((String) cbTanaman.getSelectedItem()).split(" - ")[0].trim()));
            ps.setString(2, Tugas);
            ps.setString(3, ((String)  cbStatus.getSelectedItem()) );
            
            if(ps.executeUpdate() > 0){
               JOptionPane.showMessageDialog(this, "Data Tugas berhasil ditambahkan!");
               loadDataGardenTask();
               displayTask();
                resetT();
            }
            
        } catch (SQLException e) {
            System.out.println("Error saat menambahkan data tugas: " + e.getMessage());
        }
    }
    
    private void updateDataGardenTask(){
        if (idTask.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "ID Task tidak boleh kosong!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            } 
        int ID = Integer.parseInt(idTask.getText());
        try {
             
            String sql = "UPDATE garden_tasks set status = ? WHERE task_id = ? AND plant_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
             
            ps.setString(1, ((String) cbStatus.getSelectedItem())); 
            ps.setInt(2, ID);                                     
            ps.setInt(3, Integer.parseInt(((String) cbTanaman.getSelectedItem()).split(" - ")[0].trim())); 
            
             if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(this, "Data tugas berhasil diupdate!");
                loadDataGardenTask();
                displayTask();
                resetT();
            } else {
                JOptionPane.showMessageDialog(this, "Data tugas tidak ditemukan!", "Update Data", JOptionPane.WARNING_MESSAGE);
            }
            
            
        } catch (SQLException e) {
            System.out.println("Error saat menambahkan data tugas: " + e.getMessage());
        }
    }
    
    private void deleteDataTasks() {
    int ID = Integer.parseInt(idTask.getText());
    
    int response = JOptionPane.showConfirmDialog(this, 
        "Apakah Anda yakin ingin menghapus tugas ini?", 
        "Konfirmasi Hapus", 
        JOptionPane.YES_NO_OPTION, 
        JOptionPane.QUESTION_MESSAGE);
    
    if (response == JOptionPane.YES_OPTION) {
        try {
            String sql = "DELETE FROM garden_tasks WHERE task_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, ID);

            int rowsAffected = ps.executeUpdate();  // Mengeksekusi query dan mengecek baris yang terpengaruh
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Data Tugas berhasil dihapus!");
                loadDataGardenTask();
                displayTask();
                resetT();
            } else {
                JOptionPane.showMessageDialog(this, "Data tidak ditemukan!", "Delete Data", JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException e) {
            System.out.println("Error saat menghapus data: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Error konversi ID: " + e.getMessage());
        }
    } else {
        JOptionPane.showMessageDialog(this, "Penghapusan data dibatalkan.");
    }
}

//============================Garden Task========================
    
    
//============================Plant Growth=======================
    
    private void loadDataGrowth(){
        modelGrowth.setRowCount(0);
        try {
            String sql = "SELECT g.growth_id, p.nama, g.deskripsi "
                     + "FROM plant_growth g "
                     + "JOIN plants p ON g.plant_id = p.plant_id ";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            int no = 1;
            while (rs.next()) {
                modelGrowth.addRow(new Object[]{
                    no++,
                    rs.getString("growth_id"),
                    rs.getString("nama"),
                    rs.getString("deskripsi"),
                   
            });
        }
        } catch (SQLException e) {
            System.out.println("Error loading garden task data: " + e.getMessage());
        }      
    }
    
    private void tambahDataGrowth(){
        String Deskripsi  = deskripsi.getText();
        try {
            String sql = "INSERT INTO plant_growth (plant_id, deskripsi) VALUES (?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            
            ps.setInt(1, Integer.parseInt(((String) cbTanaman2.getSelectedItem()).split(" - ")[0].trim()));
            ps.setString(2, Deskripsi);
            
            if(ps.executeUpdate() > 0){
               JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan!");
               loadDataGrowth();
               resetG();
            }
            
        } catch (SQLException e) {
            System.out.println("Error saat menambahkan data tugas: " + e.getMessage());
        }   
    }
    
    private void updateDataGrowth(){
        if (idGrowth.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "ID Growth tidak boleh kosong!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            } 
        int ID = Integer.parseInt(idGrowth.getText());
        String Catatan = deskripsi.getText();
        try {
             
            String sql = "UPDATE plant_growth set deskripsi = ? WHERE growth_id = ? AND plant_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
             
            ps.setString(1, Catatan); 
            ps.setInt(2, ID);                                     
            ps.setInt(3, Integer.parseInt(((String) cbTanaman2.getSelectedItem()).split(" - ")[0].trim())); 
            
             if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(this, "Data berhasil diupdate!");
                loadDataGrowth();
                resetG();
            } else {
                JOptionPane.showMessageDialog(this, "Data tidak ditemukan!", "Update Data", JOptionPane.WARNING_MESSAGE);
            }
            
            
        } catch (SQLException e) {
            System.out.println("Error saat mengupdate data: " + e.getMessage());
        }
    }
    
    private void deleteDataGrowth() {
    int ID = Integer.parseInt(idGrowth.getText());

    int response = JOptionPane.showConfirmDialog(this, 
        "Apakah Anda yakin ingin menghapus data pertumbuhan ini?", 
        "Konfirmasi Hapus", 
        JOptionPane.YES_NO_OPTION, 
        JOptionPane.QUESTION_MESSAGE);

    if (response == JOptionPane.YES_OPTION) {
        try {
            String sql = "DELETE FROM plant_growth WHERE growth_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, ID);

            int rowsAffected = ps.executeUpdate();  // Mengeksekusi query dan mengecek baris yang terpengaruh
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
                loadDataGrowth();
                resetG();
            } else {
                JOptionPane.showMessageDialog(this, "Data tidak ditemukan!", "Delete Data", JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException e) {
            System.out.println("Error saat menghapus data: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Error konversi ID: " + e.getMessage());
        }
    } else {
        JOptionPane.showMessageDialog(this, "Penghapusan data dibatalkan.");
    }
}

//============================Plant Growth=======================
    
//=============Reset================
    private void resetP(){
        idPlant.setText("");
        namaT.setText("");
        cbJenis.setSelectedItem(null);
        rencana.setText("");
        
        btnCreateP.setEnabled(false);
        btnDeleteP.setEnabled(false);
        btnUpdateP.setEnabled(false);
    }
    
    private void resetT(){
        idTask.setText("");
        cbTanaman.setSelectedItem(null);
        tugas.setText("");
        cbStatus.setSelectedItem(null);
        
        btnCreateT.setEnabled(false);
        btnDeleteT.setEnabled(false);
        btnUpdateT.setEnabled(false);
    }
    
    private void resetG(){
        idGrowth.setText("");
        cbTanaman2.setSelectedItem(null);
        deskripsi.setText("");
        
        btnCreateG.setEnabled(false);
        btnDeleteG.setEnabled(false);
        btnUpdateG.setEnabled(false);
    }
//=============Reset================
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kiri = new javax.swing.JPanel();
        Home = new javax.swing.JButton();
        Plants = new javax.swing.JButton();
        Tasks = new javax.swing.JButton();
        Growth = new javax.swing.JButton();
        logout = new javax.swing.JButton();
        Exit = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        atas = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        home = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lblPending = new javax.swing.JLabel();
        lblProgress = new javax.swing.JLabel();
        lblCompleted = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        plants = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        idPlant = new javax.swing.JTextField();
        namaT = new javax.swing.JTextField();
        cbJenis = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblPlants = new javax.swing.JTable();
        btnCreateP = new javax.swing.JButton();
        btnUpdateP = new javax.swing.JButton();
        btnDeleteP = new javax.swing.JButton();
        rencana = new javax.swing.JTextField();
        ResetP = new javax.swing.JButton();
        task = new javax.swing.JPanel();
        btnCreateT = new javax.swing.JButton();
        cbTanaman = new javax.swing.JComboBox<>();
        btnUpdateT = new javax.swing.JButton();
        btnDeleteT = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        idTask = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblTasks = new javax.swing.JTable();
        jLabel18 = new javax.swing.JLabel();
        cbStatus = new javax.swing.JComboBox<>();
        tugas = new javax.swing.JTextField();
        ResetT = new javax.swing.JButton();
        growth = new javax.swing.JPanel();
        btnDeleteG = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        idGrowth = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblGrowth = new javax.swing.JTable();
        btnCreateG = new javax.swing.JButton();
        cbTanaman2 = new javax.swing.JComboBox<>();
        btnUpdateG = new javax.swing.JButton();
        deskripsi = new javax.swing.JTextField();
        ResetG = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kiri.setBackground(new java.awt.Color(26, 83, 25));

        Home.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        Home.setForeground(new java.awt.Color(255, 255, 255));
        Home.setIcon(new javax.swing.ImageIcon("C:\\Users\\safik\\Downloads\\clean-house_3672451.png")); // NOI18N
        Home.setText(" HOME");
        Home.setBorderPainted(false);
        Home.setContentAreaFilled(false);
        Home.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                HomeMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                HomeMouseReleased(evt);
            }
        });
        Home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HomeActionPerformed(evt);
            }
        });

        Plants.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        Plants.setForeground(new java.awt.Color(255, 255, 255));
        Plants.setIcon(new javax.swing.ImageIcon("C:\\Users\\safik\\Downloads\\growth_8239571 (1).png")); // NOI18N
        Plants.setText(" PLANTS");
        Plants.setBorderPainted(false);
        Plants.setContentAreaFilled(false);
        Plants.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Plants.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                PlantsMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                PlantsMouseReleased(evt);
            }
        });
        Plants.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlantsActionPerformed(evt);
            }
        });

        Tasks.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        Tasks.setForeground(new java.awt.Color(255, 255, 255));
        Tasks.setIcon(new javax.swing.ImageIcon("C:\\Users\\safik\\Downloads\\check_15973201.png")); // NOI18N
        Tasks.setText(" TASKS");
        Tasks.setToolTipText("");
        Tasks.setBorderPainted(false);
        Tasks.setContentAreaFilled(false);
        Tasks.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Tasks.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TasksMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                TasksMouseReleased(evt);
            }
        });
        Tasks.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TasksActionPerformed(evt);
            }
        });

        Growth.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        Growth.setForeground(new java.awt.Color(255, 255, 255));
        Growth.setIcon(new javax.swing.ImageIcon("C:\\Users\\safik\\Downloads\\growth_8091269.png")); // NOI18N
        Growth.setText(" GROWTH");
        Growth.setBorderPainted(false);
        Growth.setContentAreaFilled(false);
        Growth.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Growth.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                GrowthMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                GrowthMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                GrowthMouseReleased(evt);
            }
        });

        logout.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        logout.setForeground(new java.awt.Color(255, 255, 255));
        logout.setText("LOG OUT");
        logout.setBorderPainted(false);
        logout.setContentAreaFilled(false);
        logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                logoutMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                logoutMouseReleased(evt);
            }
        });
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });

        Exit.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        Exit.setForeground(new java.awt.Color(255, 255, 255));
        Exit.setText("EXIT");
        Exit.setBorderPainted(false);
        Exit.setContentAreaFilled(false);
        Exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ExitMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                ExitMouseReleased(evt);
            }
        });
        Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitActionPerformed(evt);
            }
        });

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\safik\\Downloads\\plant-pot_3136551 (2).png")); // NOI18N

        javax.swing.GroupLayout kiriLayout = new javax.swing.GroupLayout(kiri);
        kiri.setLayout(kiriLayout);
        kiriLayout.setHorizontalGroup(
            kiriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Home, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Plants, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Tasks, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Growth, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(logout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Exit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(kiriLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        kiriLayout.setVerticalGroup(
            kiriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kiriLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19)
                .addComponent(Home, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Plants, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Tasks, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Growth, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 66, Short.MAX_VALUE)
                .addComponent(logout, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Exit, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        getContentPane().add(kiri, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 500));

        atas.setBackground(new java.awt.Color(46, 139, 87));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\safik\\Downloads\\clipboard_7583516.png")); // NOI18N
        jLabel1.setText("Gardener's Task Planner");
        jLabel1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);

        javax.swing.GroupLayout atasLayout = new javax.swing.GroupLayout(atas);
        atas.setLayout(atasLayout);
        atasLayout.setHorizontalGroup(
            atasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, atasLayout.createSequentialGroup()
                .addContainerGap(264, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(157, 157, 157))
        );
        atasLayout.setVerticalGroup(
            atasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, atasLayout.createSequentialGroup()
                .addContainerGap(9, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(9, 9, 9))
        );

        getContentPane().add(atas, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, 50));

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));

        home.setBackground(new java.awt.Color(187, 216, 197));

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Task Status");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Pending");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("In Progress");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setText("Completed");

        lblPending.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblPending.setText(":  -");

        lblProgress.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblProgress.setText(":  -");

        lblCompleted.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblCompleted.setText(":  -");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblCompleted)
                            .addComponent(lblPending)
                            .addComponent(lblProgress)))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(230, 230, 230)
                        .addComponent(jLabel2)))
                .addContainerGap(252, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(lblPending))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(lblProgress))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(lblCompleted))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jButton1.setBackground(new java.awt.Color(0, 102, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon("C:\\Users\\safik\\Downloads\\plant_2303673.png")); // NOI18N
        jButton1.setText("Add Plants");
        jButton1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton1.setVerifyInputWhenFocusTarget(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(0, 102, 0));
        jButton2.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setIcon(new javax.swing.ImageIcon("C:\\Users\\safik\\Downloads\\medical-checkup_10522783.png")); // NOI18N
        jButton2.setText("Add Tasks");
        jButton2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(0, 102, 0));
        jButton3.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\safik\\Downloads\\raise_2358297.png")); // NOI18N
        jButton3.setText("Add Plant Growth");
        jButton3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        jLabel7.setText("HOME");

        javax.swing.GroupLayout homeLayout = new javax.swing.GroupLayout(home);
        home.setLayout(homeLayout);
        homeLayout.setHorizontalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, homeLayout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addGroup(homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(14, 14, 14))
            .addGroup(homeLayout.createSequentialGroup()
                .addGap(275, 275, 275)
                .addComponent(jLabel7)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        homeLayout.setVerticalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(homeLayout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab1", home);

        plants.setBackground(new java.awt.Color(187, 216, 197));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel8.setText("Plants");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setText("Plant ID");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setText("Nama Tanaman");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setText("Jenis");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setText("Rencana Tugas");

        cbJenis.setMaximumRowCount(100);
        cbJenis.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Bunga", "Hias", "Pohon", "Sayuran", "Herbal", "Rumput-rumputan", "Kaktus", "Umbi-umbian" }));

        tblPlants.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblPlants.setFocusable(false);
        tblPlants.setOpaque(false);
        tblPlants.getTableHeader().setResizingAllowed(false);
        tblPlants.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(tblPlants);

        btnCreateP.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCreateP.setText("Create");
        btnCreateP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCreatePActionPerformed(evt);
            }
        });

        btnUpdateP.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnUpdateP.setText("Update");
        btnUpdateP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdatePActionPerformed(evt);
            }
        });

        btnDeleteP.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnDeleteP.setText("Delete");
        btnDeleteP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeletePActionPerformed(evt);
            }
        });

        ResetP.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ResetP.setText("Reset");
        ResetP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetPActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout plantsLayout = new javax.swing.GroupLayout(plants);
        plants.setLayout(plantsLayout);
        plantsLayout.setHorizontalGroup(
            plantsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(plantsLayout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(plantsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(plantsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel8)
                        .addGroup(plantsLayout.createSequentialGroup()
                            .addGroup(plantsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel11)
                                .addComponent(jLabel9)
                                .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGap(36, 36, 36)
                            .addGroup(plantsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(idPlant, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(namaT, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(cbJenis, javax.swing.GroupLayout.Alignment.LEADING, 0, 170, Short.MAX_VALUE)
                                .addComponent(rencana, javax.swing.GroupLayout.Alignment.LEADING))))
                    .addGroup(plantsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(plantsLayout.createSequentialGroup()
                            .addComponent(btnCreateP)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnUpdateP)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnDeleteP)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ResetP))
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        plantsLayout.setVerticalGroup(
            plantsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(plantsLayout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addGroup(plantsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(idPlant, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(plantsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(namaT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(plantsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(cbJenis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(plantsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(rencana, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(plantsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCreateP)
                    .addComponent(btnUpdateP)
                    .addComponent(btnDeleteP)
                    .addComponent(ResetP))
                .addContainerGap(42, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab2", plants);

        task.setBackground(new java.awt.Color(187, 216, 197));

        btnCreateT.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCreateT.setText("Create");
        btnCreateT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCreateTActionPerformed(evt);
            }
        });

        cbTanaman.setMaximumRowCount(100);

        btnUpdateT.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnUpdateT.setText("Update");
        btnUpdateT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateTActionPerformed(evt);
            }
        });

        btnDeleteT.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnDeleteT.setText("Delete");
        btnDeleteT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteTActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel13.setText("Tasks");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setText("Task ID");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel15.setText("Tanaman");

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel16.setText("Tugas");

        tblTasks.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblTasks.getTableHeader().setResizingAllowed(false);
        tblTasks.getTableHeader().setReorderingAllowed(false);
        jScrollPane3.setViewportView(tblTasks);

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel18.setText("Status");

        cbStatus.setMaximumRowCount(100);
        cbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pending", "In Progress", "Completed" }));

        tugas.setEditable(false);

        ResetT.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ResetT.setText("Reset");
        ResetT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout taskLayout = new javax.swing.GroupLayout(task);
        task.setLayout(taskLayout);
        taskLayout.setHorizontalGroup(
            taskLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(taskLayout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(taskLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(taskLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel13)
                        .addGroup(taskLayout.createSequentialGroup()
                            .addGroup(taskLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(taskLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel18, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
                                    .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addComponent(jLabel14))
                            .addGap(30, 30, 30)
                            .addGroup(taskLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(idTask, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(cbTanaman, javax.swing.GroupLayout.Alignment.LEADING, 0, 170, Short.MAX_VALUE)
                                .addComponent(cbStatus, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(tugas, javax.swing.GroupLayout.Alignment.LEADING))))
                    .addGroup(taskLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, taskLayout.createSequentialGroup()
                            .addComponent(btnCreateT)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnUpdateT)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnDeleteT)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ResetT))
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        taskLayout.setVerticalGroup(
            taskLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(taskLayout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jLabel13)
                .addGap(18, 18, 18)
                .addGroup(taskLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(idTask, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(taskLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(cbTanaman, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(taskLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(tugas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(taskLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(taskLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCreateT)
                    .addComponent(btnUpdateT)
                    .addComponent(btnDeleteT)
                    .addComponent(ResetT))
                .addContainerGap(36, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab3", task);

        growth.setBackground(new java.awt.Color(187, 216, 197));

        btnDeleteG.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnDeleteG.setText("Delete");
        btnDeleteG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteGActionPerformed(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel17.setText("Plant Growth");

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel19.setText("Growth ID");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel20.setText("Tanaman");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel21.setText("Deskripsi");

        tblGrowth.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblGrowth.getTableHeader().setResizingAllowed(false);
        tblGrowth.getTableHeader().setReorderingAllowed(false);
        tblGrowth.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblGrowthMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tblGrowth);

        btnCreateG.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCreateG.setText("Create");
        btnCreateG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCreateGActionPerformed(evt);
            }
        });

        cbTanaman2.setMaximumRowCount(100);

        btnUpdateG.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnUpdateG.setText("Update");
        btnUpdateG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateGActionPerformed(evt);
            }
        });

        ResetG.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ResetG.setText("Reset");
        ResetG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetGActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout growthLayout = new javax.swing.GroupLayout(growth);
        growth.setLayout(growthLayout);
        growthLayout.setHorizontalGroup(
            growthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(growthLayout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(growthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, growthLayout.createSequentialGroup()
                        .addGroup(growthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel21)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(growthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(idGrowth, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbTanaman2, 0, 170, Short.MAX_VALUE)
                            .addComponent(deskripsi))
                        .addGap(299, 299, 299))
                    .addGroup(growthLayout.createSequentialGroup()
                        .addGroup(growthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(growthLayout.createSequentialGroup()
                                .addGap(180, 180, 180)
                                .addComponent(jLabel17))
                            .addGroup(growthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, growthLayout.createSequentialGroup()
                                    .addComponent(btnCreateG)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnUpdateG)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnDeleteG)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(ResetG))
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(38, Short.MAX_VALUE))))
        );
        growthLayout.setVerticalGroup(
            growthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(growthLayout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jLabel17)
                .addGap(18, 18, 18)
                .addGroup(growthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(idGrowth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(growthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(cbTanaman2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(growthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(deskripsi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(growthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCreateG)
                    .addComponent(btnUpdateG)
                    .addComponent(btnDeleteG)
                    .addComponent(ResetG))
                .addContainerGap(43, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab4", growth);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, -50, 610, 550));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PlantsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlantsActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_PlantsActionPerformed

    private void HomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HomeActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_HomeActionPerformed

//==========================Hover Menu===========================================
    private void HomeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HomeMousePressed
        // TODO add your handling code here:
        Home.setForeground(new Color(255, 255, 255, 150));
    }//GEN-LAST:event_HomeMousePressed

    private void HomeMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HomeMouseReleased
        // TODO add your handling code here:
       Home.setForeground(Color.WHITE);
    }//GEN-LAST:event_HomeMouseReleased

    private void PlantsMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PlantsMousePressed
        // TODO add your handling code here:
        Plants.setForeground(new Color(255, 255, 255, 150));
    }//GEN-LAST:event_PlantsMousePressed

    private void PlantsMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PlantsMouseReleased
        // TODO add your handling code here:
        Plants.setForeground(Color.WHITE);
    }//GEN-LAST:event_PlantsMouseReleased

    private void TasksMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TasksMousePressed
        // TODO add your handling code here:
        Tasks.setForeground(new Color(255, 255, 255, 150));
    }//GEN-LAST:event_TasksMousePressed

    private void TasksMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TasksMouseReleased
        // TODO add your handling code here:
        Tasks.setForeground(Color.WHITE);
    }//GEN-LAST:event_TasksMouseReleased

    private void GrowthMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GrowthMousePressed
        // TODO add your handling code here:
        Growth.setForeground(new Color(255, 255, 255, 150));
    }//GEN-LAST:event_GrowthMousePressed

    private void GrowthMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GrowthMouseReleased
        // TODO add your handling code here:
        Growth.setForeground(Color.WHITE);
    }//GEN-LAST:event_GrowthMouseReleased
//==========================Hover Menu===========================================
    
    private void btnCreatePActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreatePActionPerformed
        // TODO add your handling code here:
        tambahDataPlants();
    }//GEN-LAST:event_btnCreatePActionPerformed

    private void btnUpdatePActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdatePActionPerformed
        // TODO add your handling code here:
        updateDataPlants();
    }//GEN-LAST:event_btnUpdatePActionPerformed

    private void btnDeletePActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeletePActionPerformed
        // TODO add your handling code here:
        deleteDataPlants();
    }//GEN-LAST:event_btnDeletePActionPerformed

    private void btnCreateTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreateTActionPerformed
        // TODO add your handling code here:
        tambahDataGardenTasks();
    }//GEN-LAST:event_btnCreateTActionPerformed

    private void btnUpdateTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateTActionPerformed
        // TODO add your handling code here:
        updateDataGardenTask();
    }//GEN-LAST:event_btnUpdateTActionPerformed

    private void btnDeleteTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteTActionPerformed
        // TODO add your handling code here:
        deleteDataTasks();
    }//GEN-LAST:event_btnDeleteTActionPerformed

    private void TasksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TasksActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_TasksActionPerformed

    private void btnDeleteGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteGActionPerformed
        // TODO add your handling code here:
        deleteDataGrowth();
    }//GEN-LAST:event_btnDeleteGActionPerformed

    private void btnCreateGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreateGActionPerformed
        // TODO add your handling code here:
        tambahDataGrowth();
    }//GEN-LAST:event_btnCreateGActionPerformed

    private void btnUpdateGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateGActionPerformed
        // TODO add your handling code here:
        updateDataGrowth();
    }//GEN-LAST:event_btnUpdateGActionPerformed

    private void GrowthMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GrowthMouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_GrowthMouseClicked

    private void logoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_logoutMouseClicked

    private void logoutMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMousePressed
        // TODO add your handling code here
         logout.setForeground(new Color(255, 255, 255, 150));
        
    }//GEN-LAST:event_logoutMousePressed

    private void logoutMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseReleased
        // TODO add your handling code here:
         logout.setForeground(Color.WHITE);
    }//GEN-LAST:event_logoutMouseReleased

    private void ExitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_ExitMouseClicked

    private void ExitMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitMousePressed
        // TODO add your handling code here:
        Exit.setForeground(new Color(255, 255, 255, 150));
        
    }//GEN-LAST:event_ExitMousePressed

    private void ExitMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitMouseReleased
        // TODO add your handling code here:
         Exit.setForeground(Color.WHITE);
    }//GEN-LAST:event_ExitMouseReleased

    private void ExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitActionPerformed
        // TODO add your handling code here:
        int exit = JOptionPane.showConfirmDialog(null,"Keluar Program?","Keluar",JOptionPane.YES_NO_OPTION);
        if (exit == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_ExitActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        // TODO add your handling code here:
        Login L = new Login();
        int l = JOptionPane.showConfirmDialog(null,"Ingin Log Out?","Log Out",JOptionPane.YES_NO_OPTION);
        if (l == JOptionPane.YES_OPTION) {
           L.setVisible(true);
           this.dispose();
        }
    }//GEN-LAST:event_logoutActionPerformed

    private void ResetPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetPActionPerformed
        // TODO add your handling code here:
        resetP();
    }//GEN-LAST:event_ResetPActionPerformed

    private void ResetTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetTActionPerformed
        // TODO add your handling code here:
        resetT();
    }//GEN-LAST:event_ResetTActionPerformed

    private void ResetGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetGActionPerformed
        // TODO add your handling code here:
        resetG();
    }//GEN-LAST:event_ResetGActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void tblGrowthMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblGrowthMouseClicked
//        // TODO add your handling code here:
//        int selectedRow = tblGrowth.getSelectedRow();
//        if (selectedRow != -1) {
//            // Ambil Growth ID
//            idGrowth.setText(modelGrowth.getValueAt(selectedRow, 1).toString());
////
////            // Ambil data "plant_id - nama" dan pilih di ComboBox
////            String plantIdNama = modelGrowth.getValueAt(selectedRow, 2).toString();
////            cbTanaman2.addItem(plantIdNama);
//
//              String plantIdNama = modelGrowth.getValueAt(selectedRow, 2).toString();
//              for(int i = 0; i < cbTanaman2.getItemCount(); i++){
//                  if(cbTanaman2.getItemAt(i).toString().equalsIgnoreCase(plantIdNama)){
//                      cbTanaman2.setSelectedIndex(i);
//                  }
//              }
////
////            // Ambil Deskripsi dan masukkan ke TextField deskripsi
//            deskripsi.setText(modelGrowth.getValueAt(selectedRow, 3).toString());
//        }
    }//GEN-LAST:event_tblGrowthMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Exit;
    private javax.swing.JButton Growth;
    private javax.swing.JButton Home;
    private javax.swing.JButton Plants;
    private javax.swing.JButton ResetG;
    private javax.swing.JButton ResetP;
    private javax.swing.JButton ResetT;
    private javax.swing.JButton Tasks;
    private javax.swing.JPanel atas;
    private javax.swing.JButton btnCreateG;
    private javax.swing.JButton btnCreateP;
    private javax.swing.JButton btnCreateT;
    private javax.swing.JButton btnDeleteG;
    private javax.swing.JButton btnDeleteP;
    private javax.swing.JButton btnDeleteT;
    private javax.swing.JButton btnUpdateG;
    private javax.swing.JButton btnUpdateP;
    private javax.swing.JButton btnUpdateT;
    private javax.swing.JComboBox<String> cbJenis;
    private javax.swing.JComboBox<String> cbStatus;
    private javax.swing.JComboBox<String> cbTanaman;
    private javax.swing.JComboBox<String> cbTanaman2;
    private javax.swing.JTextField deskripsi;
    private javax.swing.JPanel growth;
    private javax.swing.JPanel home;
    private javax.swing.JTextField idGrowth;
    private javax.swing.JTextField idPlant;
    private javax.swing.JTextField idTask;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel kiri;
    private javax.swing.JLabel lblCompleted;
    private javax.swing.JLabel lblPending;
    private javax.swing.JLabel lblProgress;
    private javax.swing.JButton logout;
    private javax.swing.JTextField namaT;
    private javax.swing.JPanel plants;
    private javax.swing.JTextField rencana;
    private javax.swing.JPanel task;
    private javax.swing.JTable tblGrowth;
    private javax.swing.JTable tblPlants;
    private javax.swing.JTable tblTasks;
    private javax.swing.JTextField tugas;
    // End of variables declaration//GEN-END:variables
}
